<footer>
  <div class="row">
    asdasdasdasdas
  </div>
</footer>

<script src="<?php bloginfo('template_url');?>/js/jquery.min.js"></script>
<script scr="<?php bloginfo('template_url');?>/js/bootstrap.min.js"></script>
<script scr="<?php bloginfo('template_url');?>/js/npm.js"></script>

</body>

</html>
