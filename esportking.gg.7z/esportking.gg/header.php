<!DOCTYPE html>
<html>

  <head>
    <title><?php bloginfo('name'); ?></title>
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/c_bootstrap.css" media="screen" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">

    <?php wp_head(); ?>

  </head>

  <body <?php body_class(); ?>>
