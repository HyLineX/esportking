<?php get_header(); ?>

  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">eSport King</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
          <?php
          $default = array (
          'theme_location' => 'primary',
          'container' => false,
          'menu_class' => 'nav navbar-nav',
          'depth' => 12, /*Reichweite der Nav. (1Punkt 2Punkte 3...) */
          'walker' => new wp_bootstrap_navwalker()
          );
          wp_nav_menu($default);
          ?>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">

    <div class="row wptop"> </div>

    <div class="row maincontent">

    <div class="gamelist">
      <img src="https://static-cdn.jtvnw.net/ttv-boxart/League%20of%20Legends-272x380.jpg" class="img-rounded gbox" alt="LoL" max-width="250" max-height="500">
      <img src="https://static-cdn.jtvnw.net/ttv-boxart/League%20of%20Legends-272x380.jpg" class="img-rounded gbox" alt="LoL" max-width="250" max-height="500">
      <img src="https://static-cdn.jtvnw.net/ttv-boxart/League%20of%20Legends-272x380.jpg" class="img-rounded gbox" alt="LoL" max-width="250" max-height="500">
      <img src="https://static-cdn.jtvnw.net/ttv-boxart/League%20of%20Legends-272x380.jpg" class="img-rounded gbox" alt="LoL" max-width="250" max-height="500">
      <img src="https://static-cdn.jtvnw.net/ttv-boxart/League%20of%20Legends-272x380.jpg" class="img-rounded gbox" alt="LoL" max-width="250" max-height="500">
    </div>

    </div>

  </div>

<?php get_footer(); ?>
